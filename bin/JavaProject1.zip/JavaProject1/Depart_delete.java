package JavaProject1;

import javax.swing.JFrame;

public class Depart_delete extends JFrame {

	public static void main(String[] args) {
		

	}

}
